
# coding: utf-8

# ## Notebook - Predict Airline delays and get top 10 flight origins causing delays 
# ## Using PySpark and Predictive Analysis scoring equations

# In[10]:

from pyspark.sql.types import * 
from pyspark.sql import Row
from pyspark.sql import SQLContext


# ## read original csv file from HDFS

# In[11]:

# read csv file through sql context and get a rdd, convert into rows and columns

line_split = sc.textFile("/user/i058617/2007_SNA.csv").map(lambda line: line.split(","))

#map(lambda x: Row(iden = int(x[0]), holiday_date = x[1], holiday_desc = x[2])) 
#clean_line_split = line_split.map(lambda p: (p[0:1]+ p[4:41]))
rdd_flights_attr = line_split.map(lambda p :(p[0:29]))
rdd_flights_columns = rdd_flights_attr.map(lambda x: Row(Year = long(x[0]), Month = int(x[1]), DayofMonth = float(x[2]), DayOfWeek = float(x[3]), 
DepTime  = float(x[4]), CRSDepTime = float(x[5]), ArrTime  = float(x[6]), CRSArrTime  = float(x[7]), UniqueCarrier = x[8], 
FlightNum  = float(x[9]), TailNum = x[10], ActualElapsedTime  = float(x[11]), CRSElapsedTime  = float(x[12]), 
AirTime  = float(x[13]) , ArrDelay  = float(x[14]), DepDelay  = float(x[15]), Origin  = x[16], Dest = x[17], 
Distance  = float(x[18]), TaxiIn  = float(x[19]), TaxiOut  = float(x[20]), Cancelled  = float(x[21]), 
CancellationCode  = x[22], Diverted  = float(x[23]), CarrierDelay = float(x[24]), WeatherDelay  = float(x[25]), 
NASDelay  = float(x[26]), SecurityDelay  = float(x[27]), LateAircraftDelay  = float(x[28]) ))

 
sql_c = SQLContext(sc)
flights_df = sql_c.createDataFrame( rdd_flights_columns)

#Function printschema is DF function not RDD 
flights_df.printSchema()


# ## Get details from original data - flights with delay more than 15 mins

# In[12]:


from pyspark.sql.functions import regexp_replace, col

#DF has to be registered as table before applying SQL 
sql_c.registerDataFrameAsTable(flights_df, "FLIGHTS_DELAY")
flights_delayed = sql_c.sql("select Origin, DepDelay from FLIGHTS_DELAY where DepDelay >= 15")
flights_delayed.show(20)

#countsByday = flights_df.groupBy("month").count()
#countsByday = flights_delayed.count()
print flights_delayed.count()


# In[62]:

#rdd = sc.textFile('/user/i817399/holidays_csv/USBankHolidays.csv')
#  convert each line to a Row and then row into columns
#rdd_holidays = rdd.map(lambda x: x.split(',')).map(lambda x: Row(iden = int(x[0]), holiday_date = x[1], holiday_desc = x[2])) 

#Before we can use SQL, we need to convert RDD into data frame
#sql_c = SQLContext(sc)
#df_holidays = sql_c.createDataFrame(rdd_holidays)
#Function printschema is DF function not RDD 
#df_holidays.printSchema() 
#DF has to be registered as table before applying SQL 
#sql_c.registerDataFrameAsTable(df_holidays, "holidays_table")


#holidays_ind = sql_c.sql("SELECT * from holidays_table where holiday_desc like '%Independ%' ")
#holidays_ind.show()


# ## Once PA has been used to train model on original data, get the scores for target flights

# In[13]:

#scoring sql from PA

flights_scores = sql_c.sql(""" SELECT Origin, CAST( ((CASE 
WHEN `rr_DepDelay` < -6.366187757629e0 THEN  ( 1.784669699992e-1*`rr_DepDelay`-4.244798141402e0 ) 
WHEN `rr_DepDelay` < -4.481132618381e0 THEN  ( 5.936418493806e-1*`rr_DepDelay`-1.601716907009e0 ) 
WHEN `rr_DepDelay` < -3.437652645724e0 THEN  ( 3.510372751742e-3*`rr_DepDelay`-4.246174316064e0 ) 
WHEN `rr_DepDelay` < -2.767344537748e0 THEN  ( 1.265068015581e0*`rr_DepDelay`+9.062265254161e-2 ) 
WHEN `rr_DepDelay` < -1.971851857271e0 THEN  ( 1.144267486799e0*`rr_DepDelay`-2.436740309408e-1 ) 
WHEN `rr_DepDelay` < -1.153981544331e0 THEN  ( 5.349258838202e-1*`rr_DepDelay`-1.445205402487e0 ) 
WHEN `rr_DepDelay` < -3.672734761749e-1 THEN  ( 2.579729971221e-1*`rr_DepDelay`-1.764803922385e0 ) 
WHEN `rr_DepDelay` < 4.768698990941e-1 THEN  ( 7.735994166384e-1*`rr_DepDelay`-1.575428014882e0 ) 
WHEN `rr_DepDelay` <= 1.485024370596e0 THEN  ( 7.008070281909e-1*`rr_DepDelay`-1.540715515948e0 ) 
WHEN `rr_DepDelay` < 1.599178476907e0 THEN  ( 7.008070281909e-1*`rr_DepDelay`-5.407155159483e-1 ) 
WHEN `rr_DepDelay` < 3.008003289569e0 THEN  ( 1.068341762192e0*`rr_DepDelay`-1.128469152079e0 ) 
WHEN `rr_DepDelay` < 4.442425952379e0 THEN  ( 7.935582041839e-1*`rr_DepDelay`-3.019193056708e-1 ) 
WHEN `rr_DepDelay` < 6.168832972855e0 THEN  ( 1.424512309788e0*`rr_DepDelay`-3.104886199168e0 ) 
WHEN `rr_DepDelay` < 8.603578240402e0 THEN  ( 7.250139809299e-1*`rr_DepDelay`+1.210202156351e0 ) 
WHEN `rr_DepDelay` < 1.26138317415e1 THEN  ( 9.375837464736e-1*`rr_DepDelay`-6.186584530481e-1 ) 
WHEN `rr_DepDelay` < 2.095897353749e1 THEN  ( 1.318036985761e0*`rr_DepDelay`-5.417631598927e0 ) 
WHEN `rr_DepDelay` < 3.575492805011e1 THEN  ( 8.596046883182e-1*`rr_DepDelay`+4.190638791905e0 ) 
WHEN `rr_DepDelay` >= 3.575492805011e1 THEN  ( 9.855436807933e-1*`rr_DepDelay`-3.123008227475e-1 ) 
ELSE 0.
END)) AS BIGINT )
AS ZSCORE0 
FROM 
(
SELECT Origin, 
( 
 (  (CASE 
WHEN ( `Month` IS NULL ) THEN -2.231707037348e0
WHEN `Month` IN(2)  THEN -2.453385825316e0
ELSE -2.231707037348e0
END) +
 (CASE 
WHEN ( `DayofMonth` IS NULL ) THEN 8.486088933272e-1
WHEN `DayofMonth` <= 1.0e0 THEN 8.314536850511e-1
WHEN `DayofMonth` <= 2.0e0 THEN 8.142984767749e-1
WHEN `DayofMonth` <= 3.0e0 THEN 7.971432684987e-1
WHEN `DayofMonth` <= 4.0e0 THEN 7.799880602226e-1
WHEN `DayofMonth` <= 5.0e0 THEN 7.628328519464e-1
WHEN `DayofMonth` <= 6.0e0 THEN 7.456776436703e-1
WHEN `DayofMonth` <= 7.0e0 THEN 7.285224353941e-1
WHEN `DayofMonth` <= 8.0e0 THEN -1.13716703218e-1
WHEN `DayofMonth` <= 9.0e0 THEN -1.308719114942e-1
WHEN `DayofMonth` <= 1.0e1 THEN -1.480271197703e-1
WHEN `DayofMonth` <= 1.1e1 THEN -1.651823280465e-1
WHEN `DayofMonth` <= 1.2e1 THEN -1.823375363226e-1
WHEN `DayofMonth` <= 1.3e1 THEN -1.994927445988e-1
WHEN `DayofMonth` <= 1.4e1 THEN 1.356738102329e0
WHEN `DayofMonth` <= 1.5e1 THEN 1.339582894053e0
WHEN `DayofMonth` <= 1.6e1 THEN 1.322427685777e0
WHEN `DayofMonth` <= 1.7e1 THEN 1.027650476455e-1
WHEN `DayofMonth` <= 1.8e1 THEN 8.560983936939e-2
WHEN `DayofMonth` <= 1.9e1 THEN 6.845463109324e-2
WHEN `DayofMonth` <= 2.0e1 THEN 5.129942281708e-2
WHEN `DayofMonth` <= 2.1e1 THEN 3.414421454093e-2
WHEN `DayofMonth` <= 2.2e1 THEN 1.698900626478e-2
WHEN `DayofMonth` <= 2.3e1 THEN -5.51211446101e-1
WHEN `DayofMonth` <= 2.4e1 THEN -5.683666543771e-1
WHEN `DayofMonth` <= 2.5e1 THEN -5.855218626533e-1
WHEN `DayofMonth` <= 2.6e1 THEN -6.026770709295e-1
WHEN `DayofMonth` <= 2.7e1 THEN -1.039697099642e0
WHEN `DayofMonth` <= 2.8e1 THEN -1.056852307918e0
WHEN `DayofMonth` <= 2.9e1 THEN -1.074007516194e0
WHEN `DayofMonth` <= 3.0e1 THEN -1.09116272447e0
WHEN `DayofMonth` >= 3.1e1 THEN -1.108317932747e0
ELSE -1.108317932747e0
END)+
 (CASE 
WHEN ( `DayOfWeek` IS NULL ) THEN -2.32165533756e0
WHEN `DayOfWeek` <= 1.0e0 THEN -2.395076155698e0
WHEN `DayOfWeek` <= 2.0e0 THEN -2.322425448333e0
WHEN `DayOfWeek` <= 3.0e0 THEN -2.322810503719e0
WHEN `DayOfWeek` <= 4.0e0 THEN -2.554895292872e0
WHEN `DayOfWeek` <= 5.0e0 THEN -2.555280348259e0
WHEN `DayOfWeek` <= 6.0e0 THEN -2.433551873719e0
WHEN `DayOfWeek` >= 7.0e0 THEN -2.433936929106e0
ELSE -2.433936929106e0
END)+
 (CASE 
WHEN ( `DepTime` IS NULL ) THEN -4.602727783104e-1
WHEN `DepTime` <= 0.0e0 THEN -1.297179843181e2
WHEN `DepTime` <= 6.41e2 THEN  ( 9.195323531446e-2*`DepTime`-1.297179843122e2 ) 
WHEN `DepTime` <= 6.42e2 THEN -7.072929093369e1
WHEN `DepTime` <= 6.83e2 THEN  ( 9.087266775551e-2*`DepTime`-1.290695436324e2 ) 
WHEN `DepTime` <= 7.25e2 THEN  ( 9.087266775551e-2*`DepTime`-1.29069543632e2 ) 
WHEN `DepTime` <= 8.08e2 THEN  ( 9.25023409831e-2*`DepTime`-1.302523843269e2 ) 
WHEN `DepTime` <= 8.18e2 THEN  ( 1.315025811931e-1*`DepTime`-1.617756049939e2 ) 
WHEN `DepTime` <= 8.45e2 THEN  ( 1.057455871652e-1*`DepTime`-1.407063838787e2 ) 
WHEN `DepTime` <= 9.08e2 THEN  ( 9.472683454535e-2*`DepTime`-1.313860164817e2 ) 
WHEN `DepTime` <= 1.054e3 THEN  ( 9.313020492949e-2*`DepTime`-1.299362767891e2 ) 
WHEN `DepTime` <= 1.155e3 THEN  ( 9.444808169044e-2*`DepTime`-1.313258815406e2 ) 
WHEN `DepTime` <= 1.194e3 THEN  ( 9.834471991379e-2*`DepTime`-1.358264986882e2 ) 
WHEN `DepTime` <= 1.63e3 THEN  ( 9.20051140771e-2*`DepTime`-1.282553762292e2 ) 
WHEN `DepTime` <= 1.709e3 THEN  ( 9.223733555914e-2*`DepTime`-1.286338972442e2 ) 
WHEN `DepTime` <= 1.725e3 THEN  ( 9.950797591277e-2*`DepTime`-1.410635638271e2 ) 
WHEN `DepTime` <= 1.77e3 THEN  ( 9.451609974908e-2*`DepTime`-1.324525774443e2 ) 
WHEN `DepTime` <= 1.809e3 THEN  ( 9.552761230959e-2*`DepTime`-1.342434452142e2 ) 
WHEN `DepTime` <= 2.31e3 THEN  ( 9.195323531446e-2*`DepTime`-1.276397299348e2 ) 
ELSE 8.477224364161e1
END)+
 (CASE 
WHEN ( `ArrTime` IS NULL ) THEN -1.5744065736e0
WHEN `ArrTime` <= 0.0e0 THEN 1.369114295918e2
WHEN `ArrTime` <= 9.07e2 THEN  ( -9.158595469038e-2*`ArrTime`+1.369114295835e2 ) 
WHEN `ArrTime` <= 9.08e2 THEN 5.377287753489e1
WHEN `ArrTime` <= 9.74e2 THEN  ( -9.126035419984e-2*`ArrTime`+1.366372791477e2 ) 
WHEN `ArrTime` <= 1.03e3 THEN  ( -9.11332105682e-2*`ArrTime`+1.365134392281e2 ) 
WHEN `ArrTime` <= 1.243e3 THEN  ( -9.146729686689e-2*`ArrTime`+1.368575481138e2 ) 
WHEN `ArrTime` <= 1.426e3 THEN  ( -9.14231992523e-2*`ArrTime`+1.368027078876e2 ) 
WHEN `ArrTime` <= 1.476e3 THEN  ( -9.09958218929e-2*`ArrTime`+1.361932677726e2 ) 
WHEN `ArrTime` <= 1.526e3 THEN  ( -9.09958218929e-2*`ArrTime`+1.361932677721e2 ) 
WHEN `ArrTime` <= 1.58e3 THEN  ( -9.213305394911e-2*`ArrTime`+1.379293713207e2 ) 
WHEN `ArrTime` <= 1.611e3 THEN  ( -9.335940364393e-2*`ArrTime`+1.398680626343e2 ) 
WHEN `ArrTime` <= 1.618e3 THEN  ( -9.902890607256e-2*`ArrTime`+1.490016310467e2 ) 
WHEN `ArrTime` <= 1.625e3 THEN  ( -9.902890607255e-2*`ArrTime`+1.490016310466e2 ) 
WHEN `ArrTime` <= 1.632e3 THEN  ( -8.438329462444e-2*`ArrTime`+1.251972188489e2 ) 
WHEN `ArrTime` <= 1.638e3 THEN  ( -7.702196450835e-2*`ArrTime`+1.131777735405e2 ) 
WHEN `ArrTime` <= 1.646e3 THEN  ( -8.281103878766e-2*`ArrTime`+1.2266027721e2 ) 
WHEN `ArrTime` <= 1.681e3 THEN  ( -9.105837469276e-2*`ArrTime`+1.362408429533e2 ) 
WHEN `ArrTime` <= 1.703e3 THEN  ( -9.245234918509e-2*`ArrTime`+1.385854838062e2 ) 
WHEN `ArrTime` <= 1.725e3 THEN  ( -9.245234918509e-2*`ArrTime`+1.38585483806e2 ) 
WHEN `ArrTime` <= 1.764e3 THEN  ( -9.205442083957e-2*`ArrTime`+1.378990574096e2 ) 
WHEN `ArrTime` <= 1.931e3 THEN  ( -9.161252324362e-2*`ArrTime`+1.371192059044e2 ) 
WHEN `ArrTime` <= 2.023e3 THEN  ( -9.153776581707e-2*`ArrTime`+1.369747884987e2 ) 
WHEN `ArrTime` <= 2.116e3 THEN  ( -9.153776581707e-2*`ArrTime`+1.369747884979e2 ) 
WHEN `ArrTime` <= 2.325e3 THEN  ( -9.158595469038e-2*`ArrTime`+1.370811940222e2 ) 
ELSE -7.585615063294e1
END)+
 (CASE 
WHEN ( `LateAircraftDelay` IS NULL ) THEN -5.314578331925e-1
WHEN `LateAircraftDelay` <= 0.0e0 THEN -2.331069854427e0
WHEN `LateAircraftDelay` <= 3.0e0 THEN  ( 5.998706736849e-1*`LateAircraftDelay`-2.331069854236e0 ) 
WHEN `LateAircraftDelay` <= 1.4e1 THEN  ( 2.524069929334e-1*`LateAircraftDelay`-1.224917992674e0 ) 
WHEN `LateAircraftDelay` <= 3.8e1 THEN  ( 2.340311013758e-1*`LateAircraftDelay`-9.676555102959e-1 ) 
WHEN `LateAircraftDelay` <= 4.4e1 THEN  ( 5.025645598701e-1*`LateAircraftDelay`-1.129319783312e1 ) 
WHEN `LateAircraftDelay` <= 2.08e2 THEN  ( 2.194538229244e-1*`LateAircraftDelay`+2.734484954027e0 ) 
ELSE 4.838088012229e1
END) ) 
) AS rr_DepDelay FROM FLIGHTS_DELAY
) TMPTABLE0 """)


# In[14]:

flights_scores.printSchema()
#sql_c1 = SQLContext(sc)
sql_c.registerDataFrameAsTable(flights_scores, "FLIGHTS_SCORES")
flights_delayed_scored = sql_c.sql("SELECT Origin, ZSCORE0 from FLIGHTS_SCORES where ZSCORE0 >= 15")
 


# ## Flights after scoring grouped by origin/departing location with average delay

# In[15]:


sql_c.registerDataFrameAsTable(flights_delayed_scored, "FLIGHTS_DELAYED_SCORED")
only_delayed_flights_origin = sql_c.sql("SELECT Origin, avg(ZSCORE0) as avg_delay FROM FLIGHTS_DELAYED_SCORED GROUP BY Origin ORDER BY avg_delay DESC")
only_delayed_flights_origin.printSchema()
only_delayed_flights_origin.show(20)


# ## Plot top 10 flight origins with highest amount of delay 

# In[16]:

get_ipython().magic(u'matplotlib inline')
import matplotlib.pyplot as plt
import pandas as pd
fig, ax = plt.subplots(nrows=1, ncols=1, figsize=(10,6));
flightsfq = pd.DataFrame(only_delayed_flights_origin.collect(), columns = ['Origin', 'avg_delay'])
flightsfq['avg_delay'][:10].plot(kind='bar')
ax.set_xticklabels(flightsfq['Origin'][:10])


# In[ ]:



